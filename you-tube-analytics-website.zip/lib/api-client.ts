import axios from 'axios'

// Configure the API base URL
const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:5000'

const apiClient = axios.create({
  baseURL: API_BASE_URL,
  timeout: 10000,
  headers: {
    'Content-Type': 'application/json',
  },
})

// Request interceptor
apiClient.interceptors.request.use(
  (config) => {
    return config
  },
  (error) => {
    return Promise.reject(error)
  }
)

// Response interceptor
apiClient.interceptors.response.use(
  (response) => {
    return response.data
  },
  (error) => {
    console.error('[v0] API Error:', error.message)
    return Promise.reject(error)
  }
)

export default apiClient

// API endpoints
export const analyticsApi = {
  getOverview: () => apiClient.get('/api/analytics/overview'),
  getByType: () => apiClient.get('/api/analytics/by-type'),
  getWatchTime: () => apiClient.get('/api/analytics/watch-time'),
  getPeakHours: () => apiClient.get('/api/analytics/peak-hours'),
  getCategories: () => apiClient.get('/api/analytics/categories'),
  getUserDemographics: () => apiClient.get('/api/analytics/user-demographics'),
  getTopVideos: () => apiClient.get('/api/analytics/top-videos'),
  getVideos: () => apiClient.get('/api/videos'),
}
