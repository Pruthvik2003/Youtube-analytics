'use client'

import { motion } from 'framer-motion'
import Link from 'next/link'
import Image from 'next/image'
import { ArrowLeft, Play, Zap, TrendingUp, Users } from 'lucide-react'
import { StatCounter } from '@/components/stat-counter'
import { ChartContainer } from '@/components/charts/chart-container'
import { useVideosByType, useAnalyticsOverview } from '@/hooks/useAnalytics'
import {
  BarChart,
  Bar,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  ScatterChart,
  Scatter,
} from 'recharts'

export default function VideoTypesPage() {
  const { data: videoTypeData, isLoading: videoTypeLoading } = useVideosByType()
  const { data: overviewData, isLoading: overviewLoading } = useAnalyticsOverview()

  const getTypeIcon = (type: string) => {
    return type === 'short' ? (
      <Zap className="w-5 h-5" />
    ) : (
      <Play className="w-5 h-5" />
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-primary/5">
      {/* Header */}
      <header className="border-b border-border bg-background/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center justify-between">
          <Link
            href="/"
            className="flex items-center gap-2 text-muted-foreground hover:text-primary transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Back to Dashboard</span>
          </Link>
          <h1 className="text-xl font-bold text-foreground">Video Types</h1>
          <div className="w-24" />
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Hero Section with Image */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="mb-12 relative rounded-xl overflow-hidden"
        >
          <div className="relative h-64 sm:h-80 rounded-xl overflow-hidden">
            <Image
              src="/hero-video-types.jpg"
              alt="Video Types Comparison"
              fill
              className="object-cover"
              priority
            />
            <div className="absolute inset-0 bg-gradient-to-r from-background/80 via-background/40 to-transparent flex items-center">
              <div className="relative z-10 p-6 sm:p-10">
                <motion.div
                  initial={{ opacity: 0, x: -30 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.6, delay: 0.2 }}
                >
                  <h2 className="text-3xl sm:text-5xl font-bold text-foreground mb-4">
                    Regular Videos vs Shorts
                  </h2>
                  <p className="text-base sm:text-lg text-muted-foreground max-w-xl">
                    Compare performance between traditional and short-form content
                  </p>
                </motion.div>
              </div>
            </div>
          </div>
        </motion.div>

        {/* Type Comparison Stats */}
        {videoTypeLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-12">
            {[1, 2].map((i) => (
              <div
                key={i}
                className="h-48 bg-card border border-border rounded-lg animate-pulse"
              />
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-12">
            {videoTypeData?.map((type: any) => (
              <motion.div
                key={type.type}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
                className="bg-card border border-border rounded-lg p-8 hover-card"
              >
                <div className="flex items-center gap-4 mb-6">
                  <div className={`w-12 h-12 rounded-lg flex items-center justify-center ${
                    type.type === 'short'
                      ? 'bg-accent/20 text-accent'
                      : 'bg-primary/20 text-primary'
                  }`}>
                    {getTypeIcon(type.type)}
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-foreground capitalize">
                      {type.type === 'short' ? 'Shorts' : 'Regular Videos'}
                    </h3>
                    <p className="text-sm text-muted-foreground">
                      {type.type === 'short'
                        ? 'Short-form vertical videos'
                        : 'Traditional long-form videos'}
                    </p>
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="flex justify-between items-center pb-4 border-b border-border/50">
                    <span className="text-muted-foreground">Total Views</span>
                    <span className="text-2xl font-bold text-foreground">
                      {type.total_views.toLocaleString()}
                    </span>
                  </div>
                  <div className="flex justify-between items-center pb-4 border-b border-border/50">
                    <span className="text-muted-foreground">Watch Time</span>
                    <span className="text-2xl font-bold text-foreground">
                      {type.total_watch_time_hours.toLocaleString()} hrs
                    </span>
                  </div>
                  <div className="flex justify-between items-center pb-4 border-b border-border/50">
                    <span className="text-muted-foreground">Avg Watch Time</span>
                    <span className="text-2xl font-bold text-foreground">
                      {type.avg_watch_time_minutes.toFixed(1)} min
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-muted-foreground">Completion Rate</span>
                    <div className="flex items-center gap-2">
                      <div className="w-24 h-2 bg-border rounded-full overflow-hidden">
                        <div
                          className={`h-full ${
                            type.type === 'short'
                              ? 'bg-gradient-to-r from-accent to-primary'
                              : 'bg-gradient-to-r from-primary to-accent'
                          }`}
                          style={{
                            width: `${type.completion_rate}%`,
                          }}
                        />
                      </div>
                      <span className="text-lg font-bold text-foreground w-12">
                        {type.completion_rate.toFixed(1)}%
                      </span>
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        )}

        {/* Comparison Charts */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Views Comparison */}
          {videoTypeLoading ? (
            <div className="h-80 bg-card border border-border rounded-lg animate-pulse" />
          ) : (
            <ChartContainer title="Views Comparison" description="Total views by type">
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={videoTypeData || []}>
                  <CartesianGrid
                    strokeDasharray="3 3"
                    stroke="rgba(148, 163, 184, 0.1)"
                  />
                  <XAxis dataKey="type" stroke="rgba(148, 163, 184, 0.5)" />
                  <YAxis stroke="rgba(148, 163, 184, 0.5)" />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#141b3d',
                      border: '1px solid #1e293b',
                      borderRadius: '8px',
                      color: '#ffffff',
                    }}
                  />
                  <Bar dataKey="total_views" fill="#6366f1" radius={[8, 8, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </ChartContainer>
          )}

          {/* Watch Time Comparison */}
          {videoTypeLoading ? (
            <div className="h-80 bg-card border border-border rounded-lg animate-pulse" />
          ) : (
            <ChartContainer title="Watch Time Comparison" description="Total watch time by type">
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={videoTypeData || []}>
                  <CartesianGrid
                    strokeDasharray="3 3"
                    stroke="rgba(148, 163, 184, 0.1)"
                  />
                  <XAxis dataKey="type" stroke="rgba(148, 163, 184, 0.5)" />
                  <YAxis stroke="rgba(148, 163, 184, 0.5)" />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#141b3d',
                      border: '1px solid #1e293b',
                      borderRadius: '8px',
                      color: '#ffffff',
                    }}
                  />
                  <Bar dataKey="total_watch_time_hours" fill="#06b6d4" radius={[8, 8, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </ChartContainer>
          )}
        </div>

        {/* Performance Metrics */}
        <ChartContainer
          title="Performance Metrics"
          description="Key metrics comparison"
          className="mt-6"
        >
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-background/50 rounded-lg p-6">
              <h4 className="text-sm font-semibold text-muted-foreground mb-4">
                Avg Watch Time
              </h4>
              <div className="space-y-3">
                {videoTypeData?.map((type: any) => (
                  <div key={type.type} className="flex justify-between items-center">
                    <span className="text-foreground capitalize">{type.type}</span>
                    <span className="text-lg font-bold text-accent">
                      {type.avg_watch_time_minutes.toFixed(1)} min
                    </span>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-background/50 rounded-lg p-6">
              <h4 className="text-sm font-semibold text-muted-foreground mb-4">
                Completion Rate
              </h4>
              <div className="space-y-3">
                {videoTypeData?.map((type: any) => (
                  <div key={type.type} className="flex justify-between items-center">
                    <span className="text-foreground capitalize">{type.type}</span>
                    <span className="text-lg font-bold text-primary">
                      {type.completion_rate.toFixed(1)}%
                    </span>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-background/50 rounded-lg p-6">
              <h4 className="text-sm font-semibold text-muted-foreground mb-4">
                Total Completions
              </h4>
              <div className="space-y-3">
                {videoTypeData?.map((type: any) => (
                  <div key={type.type} className="flex justify-between items-center">
                    <span className="text-foreground capitalize">{type.type}</span>
                    <span className="text-lg font-bold text-success">
                      {type.completed_views.toLocaleString()}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </ChartContainer>

        {/* Insights */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.4 }}
          className="mt-6 bg-gradient-to-r from-primary/10 to-accent/10 border border-primary/20 rounded-lg p-8"
        >
          <h3 className="text-xl font-bold text-foreground mb-4">Key Insights</h3>
          <ul className="space-y-3 text-muted-foreground">
            <li className="flex gap-3">
              <span className="text-primary font-bold">→</span>
              <span>
                Regular videos have higher average watch time compared to shorts, suggesting
                viewers are more engaged with longer-form content.
              </span>
            </li>
            <li className="flex gap-3">
              <span className="text-accent font-bold">→</span>
              <span>
                Shorts typically receive more views overall, indicating greater discoverability
                in the short-form feed.
              </span>
            </li>
            <li className="flex gap-3">
              <span className="text-primary font-bold">→</span>
              <span>
                Focus on maintaining a balanced mix of both content types to maximize reach
                and engagement.
              </span>
            </li>
          </ul>
        </motion.div>
      </main>
    </div>
  )
}
