'use client'

import { motion } from 'framer-motion'
import Link from 'next/link'
import Image from 'next/image'
import { BarChart, BarChart3, Activity, TrendingUp, Users, Clock, Zap, Eye, Play } from 'lucide-react'
import { StatCounter } from '@/components/stat-counter'
import { useAnalyticsOverview, useVideosByType, usePeakHours } from '@/hooks/useAnalytics'
import { ChartContainer } from '@/components/charts/chart-container'
import {
  BarChart as RechartsBarChart,
  Bar,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from 'recharts'

export default function Dashboard() {
  const { data: overviewData, isLoading: overviewLoading } = useAnalyticsOverview()
  const { data: typeData, isLoading: typeLoading } = useVideosByType()
  const { data: peakHoursData, isLoading: peakLoading } = usePeakHours()

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
        delayChildren: 0.3,
      },
    },
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-primary/5">
      {/* Header */}
      <header className="border-b border-border bg-background/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center justify-between">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5 }}
            className="flex items-center gap-3"
          >
            <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-primary to-accent flex items-center justify-center">
              <BarChart3 className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-foreground">YouTube Analytics</h1>
              <p className="text-xs text-muted-foreground">Content Creator Dashboard</p>
            </div>
          </motion.div>

          <nav className="flex gap-4">
            {[
              { href: '/', label: 'Dashboard', icon: '📊' },
              { href: '/analytics', label: 'Analytics', icon: '📈' },
              { href: '/video-types', label: 'Video Types', icon: '🎬' },
              { href: '/user-insights', label: 'User Insights', icon: '👥' },
            ].map((item) => (
              <Link
                key={item.href}
                href={item.href}
                className="text-xs sm:text-sm text-muted-foreground hover:text-primary transition-colors px-3 py-2 rounded-lg hover:bg-card"
              >
                <span className="mr-1">{item.icon}</span>
                <span className="hidden sm:inline">{item.label}</span>
              </Link>
            ))}
          </nav>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Hero Section with Image */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="mb-12 relative rounded-xl overflow-hidden"
        >
          <div className="relative h-64 sm:h-80 rounded-xl overflow-hidden">
            <Image
              src="/hero-dashboard.jpg"
              alt="YouTube Analytics Dashboard"
              fill
              className="object-cover"
              priority
            />
            <div className="absolute inset-0 bg-gradient-to-r from-background/80 via-background/40 to-transparent flex items-center">
              <div className="relative z-10 p-6 sm:p-10">
                <motion.div
                  initial={{ opacity: 0, x: -30 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.6, delay: 0.2 }}
                >
                  <h2 className="text-3xl sm:text-5xl font-bold text-foreground mb-4">
                    Welcome Back! 👋
                  </h2>
                  <p className="text-base sm:text-lg text-muted-foreground max-w-xl">
                    Real-time analytics for your YouTube channel with in-depth insights into viewer behavior and content performance
                  </p>
                </motion.div>
              </div>
            </div>
          </div>
        </motion.div>

        {/* Title */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.1 }}
          className="mb-8"
        >
          <h2 className="text-2xl sm:text-3xl font-bold text-foreground mb-2">
            Your Channel Performance
          </h2>
          <p className="text-muted-foreground">
            Track key metrics and discover growth opportunities
          </p>
        </motion.div>

        {/* Key Metrics - First Row */}
        {overviewLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
            {[1, 2, 3, 4].map((i) => (
              <div
                key={i}
                className="h-28 bg-card border border-border rounded-lg animate-pulse"
              />
            ))}
          </div>
        ) : (
          <motion.div
            variants={containerVariants}
            initial="hidden"
            animate="visible"
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8"
          >
            <StatCounter
              label="Total Views"
              value={overviewData?.total_views || 0}
              icon={<Eye className="w-8 h-8" />}
              suffix="views"
              animated
              color="primary"
            />
            <StatCounter
              label="Watch Time"
              value={overviewData?.total_watch_time_hours || 0}
              icon={<Clock className="w-8 h-8" />}
              suffix="hours"
              format="decimal"
              animated
              color="accent"
            />
            <StatCounter
              label="Completion Rate"
              value={overviewData?.completion_rate || 0}
              icon={<TrendingUp className="w-8 h-8" />}
              suffix="%"
              format="decimal"
              animated
              color="chart-3"
            />
            <StatCounter
              label="Total Users"
              value={overviewData?.total_users || 0}
              icon={<Users className="w-8 h-8" />}
              animated
              color="chart-4"
            />
          </motion.div>
        )}

        {/* Key Metrics - Second Row */}
        {overviewLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-12">
            {[1, 2, 3, 4].map((i) => (
              <div
                key={i}
                className="h-28 bg-card border border-border rounded-lg animate-pulse"
              />
            ))}
          </div>
        ) : (
          <motion.div
            variants={containerVariants}
            initial="hidden"
            animate="visible"
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-12"
          >
            <StatCounter
              label="Unique Videos"
              value={overviewData?.unique_videos || 0}
              icon={<Play className="w-8 h-8" />}
              animated
              color="chart-5"
            />
            <StatCounter
              label="Avg Watch Time"
              value={overviewData?.avg_watch_time_minutes || 0}
              icon={<Clock className="w-8 h-8" />}
              suffix="min"
              format="decimal"
              animated
              color="primary"
            />
            <StatCounter
              label="Engagement Rate"
              value={Math.min(overviewData?.completion_rate || 0, 100)}
              icon={<Zap className="w-8 h-8" />}
              suffix="%"
              format="decimal"
              animated
              color="accent"
            />
            <StatCounter
              label="Videos per Month"
              value={(overviewData?.unique_videos || 0) / 3}
              icon={<BarChart className="w-8 h-8" />}
              format="decimal"
              animated
              color="chart-3"
            />
          </motion.div>
        )}

        {/* Charts Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Peak Hours Chart */}
          {peakLoading ? (
            <div className="h-80 bg-card border border-border rounded-lg animate-pulse" />
          ) : (
            <ChartContainer
              title="Peak Watching Hours"
              description="Views distribution throughout the day"
            >
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={peakHoursData || []}>
                  <CartesianGrid
                    strokeDasharray="3 3"
                    stroke="rgba(148, 163, 184, 0.1)"
                  />
                  <XAxis
                    dataKey="hour"
                    stroke="rgba(148, 163, 184, 0.5)"
                    label={{ value: 'Hour of Day', position: 'insideBottomRight', offset: -5 }}
                  />
                  <YAxis stroke="rgba(148, 163, 184, 0.5)" />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#141b3d',
                      border: '1px solid #1e293b',
                      borderRadius: '8px',
                      color: '#ffffff',
                    }}
                  />
                  <Line
                    type="monotone"
                    dataKey="views"
                    stroke="#6366f1"
                    strokeWidth={2}
                    dot={{ fill: '#6366f1', r: 4 }}
                    activeDot={{ r: 6 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </ChartContainer>
          )}

          {/* Video Type Performance */}
          {typeLoading ? (
            <div className="h-80 bg-card border border-border rounded-lg animate-pulse" />
          ) : (
            <ChartContainer
              title="Video Type Performance"
              description="Regular Videos vs Shorts"
            >
              <ResponsiveContainer width="100%" height={300}>
                <RechartsBarChart data={typeData || []}>
                  <CartesianGrid
                    strokeDasharray="3 3"
                    stroke="rgba(148, 163, 184, 0.1)"
                  />
                  <XAxis
                    dataKey="type"
                    stroke="rgba(148, 163, 184, 0.5)"
                  />
                  <YAxis stroke="rgba(148, 163, 184, 0.5)" />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#141b3d',
                      border: '1px solid #1e293b',
                      borderRadius: '8px',
                      color: '#ffffff',
                    }}
                  />
                  <Legend />
                  <Bar dataKey="total_views" fill="#6366f1" radius={[8, 8, 0, 0]} />
                  <Bar dataKey="completed_views" fill="#06b6d4" radius={[8, 8, 0, 0]} />
                </RechartsBarChart>
              </ResponsiveContainer>
            </ChartContainer>
          )}
        </div>

        {/* CTA Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.5 }}
          className="mt-12 bg-gradient-to-r from-primary/10 to-accent/10 border border-primary/20 rounded-lg p-8 text-center"
        >
          <h3 className="text-2xl font-bold text-foreground mb-4">
            Explore More Analytics
          </h3>
          <p className="text-muted-foreground mb-6 max-w-2xl mx-auto">
            Dive deeper into your channel performance with detailed analytics, user
            demographics, and comprehensive video performance metrics.
          </p>
          <div className="flex gap-4 justify-center flex-wrap">
            <Link
              href="/analytics"
              className="px-6 py-3 bg-primary text-white rounded-lg font-medium hover:bg-primary/90 transition-colors"
            >
              View Full Analytics
            </Link>
            <Link
              href="/user-insights"
              className="px-6 py-3 bg-card border border-primary/30 text-foreground rounded-lg font-medium hover:bg-card/50 transition-colors"
            >
              User Insights
            </Link>
          </div>
        </motion.div>
      </main>
    </div>
  )
}
