'use client'

import { motion } from 'framer-motion'
import Link from 'next/link'
import Image from 'next/image'
import { ArrowLeft, TrendingUp, BarChart3, Zap } from 'lucide-react'
import { StatCounter } from '@/components/stat-counter'
import { ChartContainer } from '@/components/charts/chart-container'
import { useCategories, useTopVideos, usePeakHours, useWatchTime, useAnalyticsOverview } from '@/hooks/useAnalytics'
import {
  BarChart,
  Bar,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  Radar,
} from 'recharts'

const COLORS = ['#6366f1', '#06b6d4', '#8b5cf6', '#ec4899', '#f59e0b', '#10b981']

export default function AnalyticsPage() {
  const { data: overviewData, isLoading: overviewLoading } = useAnalyticsOverview()
  const { data: categoriesData, isLoading: categoriesLoading } = useCategories()
  const { data: topVideosData, isLoading: topVideosLoading } = useTopVideos()
  const { data: peakHoursData, isLoading: peakLoading } = usePeakHours()
  const { data: watchTimeData, isLoading: watchTimeLoading } = useWatchTime()

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-primary/5">
      {/* Header */}
      <header className="border-b border-border bg-background/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center justify-between">
          <Link
            href="/"
            className="flex items-center gap-2 text-muted-foreground hover:text-primary transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Back to Dashboard</span>
          </Link>
          <h1 className="text-xl font-bold text-foreground">Detailed Analytics</h1>
          <div className="w-24" />
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Hero Section with Image */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="mb-12 relative rounded-xl overflow-hidden"
        >
          <div className="relative h-64 sm:h-80 rounded-xl overflow-hidden">
            <Image
              src="/hero-analytics.jpg"
              alt="Deep Dive Analytics"
              fill
              className="object-cover"
              priority
            />
            <div className="absolute inset-0 bg-gradient-to-r from-background/80 via-background/40 to-transparent flex items-center">
              <div className="relative z-10 p-6 sm:p-10">
                <motion.div
                  initial={{ opacity: 0, x: -30 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.6, delay: 0.2 }}
                >
                  <h2 className="text-3xl sm:text-5xl font-bold text-foreground mb-4">
                    Deep Dive Analytics
                  </h2>
                  <p className="text-base sm:text-lg text-muted-foreground max-w-xl">
                    Comprehensive analysis of your channel performance with detailed insights
                  </p>
                </motion.div>
              </div>
            </div>
          </div>
        </motion.div>

        {/* Key Statistics */}
        {overviewLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-12">
            {[1, 2, 3].map((i) => (
              <div
                key={i}
                className="h-28 bg-card border border-border rounded-lg animate-pulse"
              />
            ))}
          </div>
        ) : (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ staggerChildren: 0.1, delayChildren: 0.2 }}
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-12"
          >
            <StatCounter
              label="Total Views"
              value={overviewData?.total_views || 0}
              icon={<TrendingUp className="w-8 h-8" />}
              suffix="views"
              animated
              color="primary"
            />
            <StatCounter
              label="Watch Time"
              value={overviewData?.total_watch_time_hours || 0}
              icon={<BarChart3 className="w-8 h-8" />}
              suffix="hours"
              format="decimal"
              animated
              color="accent"
            />
            <StatCounter
              label="Engagement"
              value={overviewData?.completion_rate || 0}
              icon={<Zap className="w-8 h-8" />}
              suffix="%"
              format="decimal"
              animated
              color="chart-2"
            />
          </motion.div>
        )}

        {/* First Row - Categories and Radar */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
          {/* Categories Breakdown */}
          {categoriesLoading ? (
            <div className="h-96 bg-card border border-border rounded-lg animate-pulse" />
          ) : (
            <ChartContainer
              title="Content Categories"
              description="Views by content category"
            >
              <ResponsiveContainer width="100%" height={350}>
                <PieChart>
                  <Pie
                    data={categoriesData?.slice(0, 6) || []}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ category, percent }) =>
                      `${category} ${(percent * 100).toFixed(0)}%`
                    }
                    outerRadius={100}
                    fill="#8884d8"
                    dataKey="total_views"
                  >
                    {categoriesData?.map((_, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#141b3d',
                      border: '1px solid #1e293b',
                      borderRadius: '8px',
                      color: '#ffffff',
                    }}
                  />
                </PieChart>
              </ResponsiveContainer>
            </ChartContainer>
          )}

          {/* Watch Time Distribution */}
          {watchTimeLoading ? (
            <div className="h-96 bg-card border border-border rounded-lg animate-pulse" />
          ) : (
            <ChartContainer
              title="Watch Time by User Segment"
              description="Average watch time per user segment"
            >
              <ResponsiveContainer width="100%" height={350}>
                <RadarChart data={watchTimeData || []}>
                  <PolarGrid stroke="rgba(148, 163, 184, 0.1)" />
                  <PolarAngleAxis
                    dataKey="segment"
                    stroke="rgba(148, 163, 184, 0.5)"
                  />
                  <PolarRadiusAxis stroke="rgba(148, 163, 184, 0.5)" />
                  <Radar
                    name="Avg Watch Time (min)"
                    dataKey="avg_watch_time_minutes"
                    stroke="#6366f1"
                    fill="#6366f1"
                    fillOpacity={0.6}
                  />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#141b3d',
                      border: '1px solid #1e293b',
                      borderRadius: '8px',
                      color: '#ffffff',
                    }}
                  />
                </RadarChart>
              </ResponsiveContainer>
            </ChartContainer>
          )}
        </div>

        {/* Second Row - Peak Hours */}
        {peakLoading ? (
          <div className="h-80 bg-card border border-border rounded-lg animate-pulse mb-6" />
        ) : (
          <ChartContainer
            title="Peak Hours Analysis"
            description="Viewer activity throughout the day"
            className="mb-6"
          >
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={peakHoursData || []}>
                <CartesianGrid
                  strokeDasharray="3 3"
                  stroke="rgba(148, 163, 184, 0.1)"
                />
                <XAxis
                  dataKey="hour"
                  stroke="rgba(148, 163, 184, 0.5)"
                  label={{ value: 'Hour of Day', position: 'insideBottomRight', offset: -5 }}
                />
                <YAxis stroke="rgba(148, 163, 184, 0.5)" />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#141b3d',
                    border: '1px solid #1e293b',
                    borderRadius: '8px',
                    color: '#ffffff',
                  }}
                />
                <Legend />
                <Bar dataKey="views" fill="#6366f1" radius={[8, 8, 0, 0]} />
                <Bar dataKey="completions" fill="#06b6d4" radius={[8, 8, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </ChartContainer>
        )}

        {/* Top Videos Table */}
        {topVideosLoading ? (
          <div className="h-96 bg-card border border-border rounded-lg animate-pulse" />
        ) : (
          <ChartContainer title="Top Performing Videos" description="Your best performing content">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-border">
                    <th className="text-left py-3 px-4 text-muted-foreground font-semibold">
                      Video Title
                    </th>
                    <th className="text-left py-3 px-4 text-muted-foreground font-semibold">
                      Type
                    </th>
                    <th className="text-left py-3 px-4 text-muted-foreground font-semibold">
                      Views
                    </th>
                    <th className="text-left py-3 px-4 text-muted-foreground font-semibold">
                      Completion
                    </th>
                    <th className="text-left py-3 px-4 text-muted-foreground font-semibold">
                      Avg Watch
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {topVideosData?.map((video: any, index: number) => (
                    <motion.tr
                      key={video.video_id}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: index * 0.05 }}
                      className="border-b border-border/50 hover:bg-card/50 transition-colors"
                    >
                      <td className="py-3 px-4 text-foreground font-medium truncate">
                        {video.title}
                      </td>
                      <td className="py-3 px-4">
                        <span className="text-xs bg-primary/20 text-primary px-2 py-1 rounded">
                          {video.type === 'short' ? '🎬 Short' : '📹 Video'}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-foreground">
                        {video.total_views.toLocaleString()}
                      </td>
                      <td className="py-3 px-4 text-foreground">
                        <div className="flex items-center gap-2">
                          <div className="w-16 h-2 bg-border rounded-full overflow-hidden">
                            <div
                              className="h-full bg-gradient-to-r from-primary to-accent"
                              style={{
                                width: `${video.completion_rate}%`,
                              }}
                            />
                          </div>
                          <span className="text-xs text-muted-foreground w-8">
                            {video.completion_rate.toFixed(0)}%
                          </span>
                        </div>
                      </td>
                      <td className="py-3 px-4 text-foreground">
                        {video.avg_watch_time_minutes.toFixed(1)} min
                      </td>
                    </motion.tr>
                  ))}
                </tbody>
              </table>
            </div>
          </ChartContainer>
        )}
      </main>
    </div>
  )
}
