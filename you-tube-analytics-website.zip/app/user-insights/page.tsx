'use client'

import { motion } from 'framer-motion'
import Link from 'next/link'
import Image from 'next/image'
import { ArrowLeft, Users, TrendingUp, BarChart3, Eye, Clock, Activity } from 'lucide-react'
import { StatCounter } from '@/components/stat-counter'
import { ChartContainer } from '@/components/charts/chart-container'
import { useUserDemographics, useWatchTime, useAnalyticsOverview } from '@/hooks/useAnalytics'
import {
  BarChart,
  Bar,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  Radar,
} from 'recharts'

export default function UserInsightsPage() {
  const { data: overviewData, isLoading: overviewLoading } = useAnalyticsOverview()
  const { data: demographicsData, isLoading: demographicsLoading } =
    useUserDemographics()
  const { data: watchTimeData, isLoading: watchTimeLoading } = useWatchTime()

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-primary/5">
      {/* Header */}
      <header className="border-b border-border bg-background/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center justify-between">
          <Link
            href="/"
            className="flex items-center gap-2 text-muted-foreground hover:text-primary transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Back to Dashboard</span>
          </Link>
          <h1 className="text-xl font-bold text-foreground">User Insights</h1>
          <div className="w-24" />
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Hero Section with Image */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="mb-12 relative rounded-xl overflow-hidden"
        >
          <div className="relative h-64 sm:h-80 rounded-xl overflow-hidden">
            <Image
              src="/hero-user-insights.jpg"
              alt="User Insights"
              fill
              className="object-cover"
              priority
            />
            <div className="absolute inset-0 bg-gradient-to-r from-background/80 via-background/40 to-transparent flex items-center">
              <div className="relative z-10 p-6 sm:p-10">
                <motion.div
                  initial={{ opacity: 0, x: -30 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.6, delay: 0.2 }}
                >
                  <h2 className="text-3xl sm:text-5xl font-bold text-foreground mb-4">
                    User Behavior & Demographics
                  </h2>
                  <p className="text-base sm:text-lg text-muted-foreground max-w-xl">
                    Understand your audience segments and their engagement patterns
                  </p>
                </motion.div>
              </div>
            </div>
          </div>
        </motion.div>

        {/* Key User Metrics */}
        {overviewLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-12">
            {[1, 2, 3].map((i) => (
              <div
                key={i}
                className="h-28 bg-card border border-border rounded-lg animate-pulse"
              />
            ))}
          </div>
        ) : (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ staggerChildren: 0.1, delayChildren: 0.2 }}
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-12"
          >
            <StatCounter
              label="Total Users"
              value={overviewData?.total_users || 0}
              icon={<Users className="w-8 h-8" />}
              animated
              color="primary"
            />
            <StatCounter
              label="Avg Watch Time"
              value={overviewData?.avg_watch_time_minutes || 0}
              icon={<Clock className="w-8 h-8" />}
              suffix="min"
              format="decimal"
              animated
              color="accent"
            />
            <StatCounter
              label="Return Viewers"
              value={Math.round((overviewData?.total_users || 0) * 0.35)}
              icon={<Activity className="w-8 h-8" />}
              animated
              color="chart-3"
            />
          </motion.div>
        )}

        {/* User Segments Table */}
        {demographicsLoading ? (
          <div className="h-96 bg-card border border-border rounded-lg animate-pulse mb-6" />
        ) : (
          <ChartContainer title="User Segments Analysis" description="Detailed breakdown by segment" className="mb-6">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-border">
                    <th className="text-left py-3 px-4 text-muted-foreground font-semibold">
                      Segment
                    </th>
                    <th className="text-left py-3 px-4 text-muted-foreground font-semibold">
                      Total Users
                    </th>
                    <th className="text-left py-3 px-4 text-muted-foreground font-semibold">
                      Avg Watch Time
                    </th>
                    <th className="text-left py-3 px-4 text-muted-foreground font-semibold">
                      Videos/Week
                    </th>
                    <th className="text-left py-3 px-4 text-muted-foreground font-semibold">
                      Engagement
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {demographicsData?.map((segment: any, index: number) => (
                    <motion.tr
                      key={segment.segment}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: index * 0.05 }}
                      className="border-b border-border/50 hover:bg-card/50 transition-colors"
                    >
                      <td className="py-3 px-4 text-foreground font-medium capitalize">
                        {segment.segment.replace(/_/g, ' ')}
                      </td>
                      <td className="py-3 px-4 text-foreground">
                        {segment.total_users.toLocaleString()}
                      </td>
                      <td className="py-3 px-4 text-foreground">
                        {segment.avg_watch_time_minutes.toFixed(1)} min
                      </td>
                      <td className="py-3 px-4 text-foreground">
                        {segment.avg_videos_per_week.toFixed(1)}
                      </td>
                      <td className="py-3 px-4">
                        <div className="flex items-center gap-2">
                          <div className="w-20 h-2 bg-border rounded-full overflow-hidden">
                            <div
                              className="h-full bg-gradient-to-r from-primary to-accent"
                              style={{
                                width: `${segment.engagement_rate}%`,
                              }}
                            />
                          </div>
                          <span className="text-xs text-muted-foreground w-8">
                            {segment.engagement_rate.toFixed(0)}%
                          </span>
                        </div>
                      </td>
                    </motion.tr>
                  ))}
                </tbody>
              </table>
            </div>
          </ChartContainer>
        )}

        {/* Charts Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
          {/* Watch Time Distribution */}
          {watchTimeLoading ? (
            <div className="h-80 bg-card border border-border rounded-lg animate-pulse" />
          ) : (
            <ChartContainer title="Watch Time by Segment" description="Average viewing duration">
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={watchTimeData || []}>
                  <CartesianGrid
                    strokeDasharray="3 3"
                    stroke="rgba(148, 163, 184, 0.1)"
                  />
                  <XAxis
                    dataKey="segment"
                    angle={-45}
                    textAnchor="end"
                    height={80}
                    stroke="rgba(148, 163, 184, 0.5)"
                    tick={{ fontSize: 12 }}
                  />
                  <YAxis stroke="rgba(148, 163, 184, 0.5)" />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#141b3d',
                      border: '1px solid #1e293b',
                      borderRadius: '8px',
                      color: '#ffffff',
                    }}
                  />
                  <Bar
                    dataKey="avg_watch_time_minutes"
                    fill="#6366f1"
                    radius={[8, 8, 0, 0]}
                  />
                </BarChart>
              </ResponsiveContainer>
            </ChartContainer>
          )}

          {/* Engagement Radar */}
          {demographicsLoading ? (
            <div className="h-80 bg-card border border-border rounded-lg animate-pulse" />
          ) : (
            <ChartContainer title="Engagement Profile" description="Multi-dimensional view">
              <ResponsiveContainer width="100%" height={300}>
                <RadarChart data={demographicsData || []}>
                  <PolarGrid stroke="rgba(148, 163, 184, 0.1)" />
                  <PolarAngleAxis
                    dataKey="segment"
                    tick={{ fontSize: 12 }}
                    stroke="rgba(148, 163, 184, 0.5)"
                  />
                  <PolarRadiusAxis stroke="rgba(148, 163, 184, 0.5)" />
                  <Radar
                    name="Engagement %"
                    dataKey="engagement_rate"
                    stroke="#6366f1"
                    fill="#6366f1"
                    fillOpacity={0.6}
                  />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#141b3d',
                      border: '1px solid #1e293b',
                      borderRadius: '8px',
                      color: '#ffffff',
                    }}
                  />
                </RadarChart>
              </ResponsiveContainer>
            </ChartContainer>
          )}
        </div>

        {/* Segment Cards */}
        {demographicsLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[1, 2, 3].map((i) => (
              <div
                key={i}
                className="h-48 bg-card border border-border rounded-lg animate-pulse"
              />
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-6">
            {demographicsData?.map((segment: any, index: number) => (
              <motion.div
                key={segment.segment}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="bg-card border border-border rounded-lg p-6 hover-card"
              >
                <h3 className="text-lg font-bold text-foreground mb-4 capitalize">
                  {segment.segment.replace(/_/g, ' ')}
                </h3>
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-muted-foreground text-sm">Users</span>
                    <span className="font-bold text-foreground">
                      {segment.total_users.toLocaleString()}
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-muted-foreground text-sm">Watch Time</span>
                    <span className="font-bold text-foreground">
                      {segment.avg_watch_time_minutes.toFixed(1)} min
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-muted-foreground text-sm">Videos/Week</span>
                    <span className="font-bold text-foreground">
                      {segment.avg_videos_per_week.toFixed(1)}
                    </span>
                  </div>
                  <div className="pt-3 border-t border-border">
                    <div className="flex items-center justify-between">
                      <span className="text-muted-foreground text-sm">Engagement</span>
                      <span className="font-bold text-accent">
                        {segment.engagement_rate.toFixed(0)}%
                      </span>
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        )}

        {/* Video Viewing Pattern */}
        {watchTimeLoading ? (
          <div className="h-80 bg-card border border-border rounded-lg animate-pulse" />
        ) : (
          <ChartContainer
            title="Viewing Pattern Analysis"
            description="Video consumption per segment"
            className="mb-6"
          >
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={watchTimeData || []}>
                <CartesianGrid
                  strokeDasharray="3 3"
                  stroke="rgba(148, 163, 184, 0.1)"
                />
                <XAxis
                  dataKey="segment"
                  angle={-45}
                  textAnchor="end"
                  height={80}
                  stroke="rgba(148, 163, 184, 0.5)"
                  tick={{ fontSize: 12 }}
                />
                <YAxis stroke="rgba(148, 163, 184, 0.5)" />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#141b3d',
                    border: '1px solid #1e293b',
                    borderRadius: '8px',
                    color: '#ffffff',
                  }}
                />
                <Legend />
                <Line
                  type="monotone"
                  dataKey="view_count"
                  stroke="#6366f1"
                  strokeWidth={2}
                  dot={{ fill: '#6366f1', r: 4 }}
                  name="Total Views"
                />
                <Line
                  type="monotone"
                  dataKey="avg_watch_time_minutes"
                  stroke="#06b6d4"
                  strokeWidth={2}
                  dot={{ fill: '#06b6d4', r: 4 }}
                  name="Avg Watch Time (min)"
                />
              </LineChart>
            </ResponsiveContainer>
          </ChartContainer>
        )}

        {/* Recommendations */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.4 }}
          className="bg-gradient-to-r from-primary/10 to-accent/10 border border-primary/20 rounded-lg p-8"
        >
          <h3 className="text-xl font-bold text-foreground mb-4 flex items-center gap-2">
            <TrendingUp className="w-5 h-5" />
            Recommendations
          </h3>
          <div className="space-y-3 text-muted-foreground">
            <div className="flex gap-3">
              <span className="text-primary font-bold text-lg">1.</span>
              <p>
                Target your content towards high-engagement segments like <strong>professionals</strong> and
                <strong>fitness enthusiasts</strong> who show 65-72% engagement rates.
              </p>
            </div>
            <div className="flex gap-3">
              <span className="text-accent font-bold text-lg">2.</span>
              <p>
                Focus on casual viewers as they represent your largest audience segment and
                offer significant growth potential with optimized content.
              </p>
            </div>
            <div className="flex gap-3">
              <span className="text-primary font-bold text-lg">3.</span>
              <p>
                Increase watch time for students segment by creating longer, more detailed
                educational content tailored to their interests.
              </p>
            </div>
            <div className="flex gap-3">
              <span className="text-accent font-bold text-lg">4.</span>
              <p>
                Consider geographic patterns in your user base and create region-specific
                content variations to increase engagement.
              </p>
            </div>
          </div>
        </motion.div>
      </main>
    </div>
  )
}
