import useSWR from 'swr'
import { analyticsApi } from '@/lib/api-client'

export function useAnalyticsOverview() {
  const { data, error, isLoading } = useSWR(
    'analytics-overview',
    () => analyticsApi.getOverview(),
    {
      revalidateOnFocus: false,
      revalidateOnReconnect: false,
    }
  )

  return {
    data: data?.data,
    isLoading,
    error,
  }
}

export function useVideosByType() {
  const { data, error, isLoading } = useSWR(
    'videos-by-type',
    () => analyticsApi.getByType(),
    {
      revalidateOnFocus: false,
    }
  )

  return {
    data: data?.data,
    isLoading,
    error,
  }
}

export function useWatchTime() {
  const { data, error, isLoading } = useSWR(
    'watch-time',
    () => analyticsApi.getWatchTime(),
    {
      revalidateOnFocus: false,
    }
  )

  return {
    data: data?.data,
    isLoading,
    error,
  }
}

export function usePeakHours() {
  const { data, error, isLoading } = useSWR(
    'peak-hours',
    () => analyticsApi.getPeakHours(),
    {
      revalidateOnFocus: false,
    }
  )

  return {
    data: data?.data,
    isLoading,
    error,
  }
}

export function useCategories() {
  const { data, error, isLoading } = useSWR(
    'categories',
    () => analyticsApi.getCategories(),
    {
      revalidateOnFocus: false,
    }
  )

  return {
    data: data?.data,
    isLoading,
    error,
  }
}

export function useUserDemographics() {
  const { data, error, isLoading } = useSWR(
    'user-demographics',
    () => analyticsApi.getUserDemographics(),
    {
      revalidateOnFocus: false,
    }
  )

  return {
    data: data?.data,
    isLoading,
    error,
  }
}

export function useTopVideos() {
  const { data, error, isLoading } = useSWR(
    'top-videos',
    () => analyticsApi.getTopVideos(),
    {
      revalidateOnFocus: false,
    }
  )

  return {
    data: data?.data,
    isLoading,
    error,
  }
}
