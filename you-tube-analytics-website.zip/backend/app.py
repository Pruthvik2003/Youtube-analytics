from flask import Flask, jsonify
from flask_cors import CORS
import pandas as pd
import numpy as np
import os
from datetime import datetime, timedelta

app = Flask(__name__)
CORS(app)

# Load data
def load_data():
    data_dir = os.path.join(os.path.dirname(__file__), 'data')
    videos_df = pd.read_csv(os.path.join(data_dir, 'videos.csv'))
    views_df = pd.read_csv(os.path.join(data_dir, 'views.csv'))
    users_df = pd.read_csv(os.path.join(data_dir, 'user_data.csv'))
    return videos_df, views_df, users_df

videos_df, views_df, users_df = load_data()

@app.route('/api/videos', methods=['GET'])
def get_videos():
    """Get all videos"""
    videos_list = videos_df.to_dict('records')
    return jsonify({
        'success': True,
        'data': videos_list,
        'count': len(videos_list)
    })

@app.route('/api/analytics/overview', methods=['GET'])
def get_overview():
    """Get key metrics overview"""
    total_views = len(views_df)
    total_watch_time = views_df['watch_duration_seconds'].sum() / 3600  # Convert to hours
    completion_rate = (views_df['completed'].sum() / total_views) * 100
    unique_videos = views_df['video_id'].nunique()
    
    # Calculate avg watch time
    avg_watch_time = views_df['watch_duration_seconds'].mean() / 60  # Convert to minutes
    
    return jsonify({
        'success': True,
        'data': {
            'total_views': int(total_views),
            'total_watch_time_hours': round(total_watch_time, 2),
            'completion_rate': round(completion_rate, 2),
            'unique_videos': int(unique_videos),
            'avg_watch_time_minutes': round(avg_watch_time, 2),
            'total_users': int(users_df['total_users'].sum())
        }
    })

@app.route('/api/analytics/by-type', methods=['GET'])
def get_by_type():
    """Views breakdown by video type (Regular/Shorts)"""
    # Merge views with videos to get type info
    merged = views_df.merge(videos_df[['video_id', 'type']], on='video_id')
    
    type_stats = merged.groupby('type').agg({
        'video_id': 'count',
        'watch_duration_seconds': ['sum', 'mean'],
        'completed': 'sum'
    }).round(2)
    
    type_stats.columns = ['total_views', 'total_watch_time_seconds', 'avg_watch_time_seconds', 'completed_views']
    
    result = []
    for video_type, row in type_stats.iterrows():
        result.append({
            'type': video_type,
            'total_views': int(row['total_views']),
            'total_watch_time_hours': round(row['total_watch_time_seconds'] / 3600, 2),
            'avg_watch_time_minutes': round(row['avg_watch_time_seconds'] / 60, 2),
            'completed_views': int(row['completed_views']),
            'completion_rate': round((row['completed_views'] / row['total_views']) * 100, 2)
        })
    
    return jsonify({
        'success': True,
        'data': result
    })

@app.route('/api/analytics/watch-time', methods=['GET'])
def get_watch_time():
    """User watch time distribution by segment"""
    user_watch = views_df.groupby('user_segment').agg({
        'watch_duration_seconds': ['sum', 'mean', 'count']
    }).round(2)
    
    user_watch.columns = ['total_seconds', 'avg_seconds', 'view_count']
    
    result = []
    for segment, row in user_watch.iterrows():
        result.append({
            'segment': segment,
            'total_watch_time_hours': round(row['total_seconds'] / 3600, 2),
            'avg_watch_time_minutes': round(row['avg_seconds'] / 60, 2),
            'view_count': int(row['view_count']),
            'completion_rate': round((views_df[views_df['user_segment'] == segment]['completed'].sum() / 
                                     row['view_count']) * 100, 2)
        })
    
    return jsonify({
        'success': True,
        'data': result
    })

@app.route('/api/analytics/peak-hours', methods=['GET'])
def get_peak_hours():
    """Peak watching hours"""
    views_df['timestamp'] = pd.to_datetime(views_df['timestamp'])
    views_df['hour'] = views_df['timestamp'].dt.hour
    
    hourly_stats = views_df.groupby('hour').agg({
        'video_id': 'count',
        'watch_duration_seconds': 'mean',
        'completed': 'sum'
    }).round(2)
    
    hourly_stats.columns = ['views', 'avg_watch_time', 'completions']
    
    result = []
    for hour, row in hourly_stats.iterrows():
        result.append({
            'hour': int(hour),
            'views': int(row['views']),
            'avg_watch_time_minutes': round(row['avg_watch_time'] / 60, 2),
            'completions': int(row['completions'])
        })
    
    return jsonify({
        'success': True,
        'data': result
    })

@app.route('/api/analytics/categories', methods=['GET'])
def get_categories():
    """Top content categories"""
    merged = views_df.merge(videos_df[['video_id', 'category']], on='video_id')
    
    category_stats = merged.groupby('category').agg({
        'video_id': 'count',
        'watch_duration_seconds': ['sum', 'mean'],
        'completed': 'sum'
    }).round(2)
    
    category_stats.columns = ['total_views', 'total_watch_time_seconds', 'avg_watch_time_seconds', 'completed_views']
    
    result = []
    for category, row in category_stats.iterrows():
        result.append({
            'category': category,
            'total_views': int(row['total_views']),
            'total_watch_time_hours': round(row['total_watch_time_seconds'] / 3600, 2),
            'avg_watch_time_minutes': round(row['avg_watch_time_seconds'] / 60, 2),
            'completed_views': int(row['completed_views']),
            'completion_rate': round((row['completed_views'] / row['total_views']) * 100, 2)
        })
    
    # Sort by total views descending
    result = sorted(result, key=lambda x: x['total_views'], reverse=True)
    
    return jsonify({
        'success': True,
        'data': result
    })

@app.route('/api/analytics/user-demographics', methods=['GET'])
def get_user_demographics():
    """User segment analysis"""
    segments = users_df.groupby('segment_name').agg({
        'total_users': 'sum',
        'avg_watch_time_minutes': 'mean',
        'avg_videos_per_week': 'mean',
        'engagement_rate': 'mean'
    }).round(2)
    
    result = []
    for segment, row in segments.iterrows():
        result.append({
            'segment': segment,
            'total_users': int(row['total_users']),
            'avg_watch_time_minutes': round(row['avg_watch_time_minutes'], 2),
            'avg_videos_per_week': round(row['avg_videos_per_week'], 2),
            'engagement_rate': round(row['engagement_rate'] * 100, 2)
        })
    
    return jsonify({
        'success': True,
        'data': result
    })

@app.route('/api/analytics/top-videos', methods=['GET'])
def get_top_videos():
    """Top performing videos"""
    merged = views_df.merge(videos_df[['video_id', 'title', 'type', 'category']], on='video_id')
    
    video_stats = merged.groupby(['video_id', 'title', 'type', 'category']).agg({
        'watch_duration_seconds': ['count', 'sum', 'mean'],
        'completed': 'sum'
    }).round(2)
    
    video_stats.columns = ['total_views', 'total_watch_time_seconds', 'avg_watch_time_seconds', 'completed_views']
    
    result = []
    for (video_id, title, video_type, category), row in video_stats.iterrows():
        result.append({
            'video_id': video_id,
            'title': title,
            'type': video_type,
            'category': category,
            'total_views': int(row['total_views']),
            'total_watch_time_hours': round(row['total_watch_time_seconds'] / 3600, 2),
            'avg_watch_time_minutes': round(row['avg_watch_time_seconds'] / 60, 2),
            'completed_views': int(row['completed_views']),
            'completion_rate': round((row['completed_views'] / row['total_views']) * 100, 2)
        })
    
    # Sort by total views
    result = sorted(result, key=lambda x: x['total_views'], reverse=True)[:10]
    
    return jsonify({
        'success': True,
        'data': result
    })

@app.route('/health', methods=['GET'])
def health():
    """Health check endpoint"""
    return jsonify({'status': 'healthy'})

if __name__ == '__main__':
    app.run(debug=True, port=5000)
