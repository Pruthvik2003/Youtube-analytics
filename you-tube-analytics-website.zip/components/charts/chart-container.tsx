'use client'

import { motion } from 'framer-motion'
import { ReactNode } from 'react'

interface ChartContainerProps {
  title: string
  description?: string
  children: ReactNode
  className?: string
}

export function ChartContainer({
  title,
  description,
  children,
  className = '',
}: ChartContainerProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className={`bg-card border border-border rounded-lg p-6 hover-card ${className}`}
    >
      <div className="mb-6">
        <h3 className="text-lg font-semibold text-foreground">{title}</h3>
        {description && (
          <p className="text-sm text-muted-foreground mt-1">{description}</p>
        )}
      </div>
      <div className="w-full overflow-x-auto">{children}</div>
    </motion.div>
  )
}
