'use client'

import { motion } from 'framer-motion'
import { useEffect, useState } from 'react'
import { ReactNode } from 'react'

interface StatCounterProps {
  label: string
  value: number | string
  icon?: ReactNode
  suffix?: string
  prefix?: string
  format?: 'number' | 'decimal'
  animated?: boolean
  color?: 'primary' | 'accent' | 'chart-1' | 'chart-2' | 'chart-3' | 'chart-4' | 'chart-5'
}

const colorMap: Record<string, { bg: string; iconColor: string; gradient: string }> = {
  primary: { bg: 'from-primary/10', iconColor: 'text-primary', gradient: 'from-primary to-accent' },
  accent: { bg: 'from-accent/10', iconColor: 'text-accent', gradient: 'from-accent to-primary' },
  'chart-1': { bg: 'from-purple-500/10', iconColor: 'text-purple-400', gradient: 'from-purple-400 to-pink-400' },
  'chart-2': { bg: 'from-cyan-500/10', iconColor: 'text-cyan-400', gradient: 'from-cyan-400 to-blue-400' },
  'chart-3': { bg: 'from-violet-500/10', iconColor: 'text-violet-400', gradient: 'from-violet-400 to-purple-400' },
  'chart-4': { bg: 'from-pink-500/10', iconColor: 'text-pink-400', gradient: 'from-pink-400 to-rose-400' },
  'chart-5': { bg: 'from-amber-500/10', iconColor: 'text-amber-400', gradient: 'from-amber-400 to-orange-400' },
}

export function StatCounter({
  label,
  value,
  icon,
  suffix = '',
  prefix = '',
  format = 'number',
  animated = true,
  color = 'primary',
}: StatCounterProps) {
  const [displayValue, setDisplayValue] = useState(0)
  const colorTheme = colorMap[color]

  useEffect(() => {
    if (!animated || typeof value !== 'number') {
      setDisplayValue(typeof value === 'number' ? value : 0)
      return
    }

    let startValue = 0
    const targetValue = value
    const duration = 2000
    const startTime = Date.now()

    const animate = () => {
      const elapsed = Date.now() - startTime
      const progress = Math.min(elapsed / duration, 1)
      const currentValue = Math.floor(startValue + (targetValue - startValue) * progress)
      setDisplayValue(currentValue)

      if (progress < 1) {
        requestAnimationFrame(animate)
      }
    }

    animate()
  }, [value, animated])

  const formattedValue =
    format === 'decimal'
      ? displayValue.toFixed(2)
      : displayValue.toLocaleString()

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      whileHover={{ y: -5, transition: { duration: 0.2 } }}
      className={`bg-gradient-to-br bg-card border border-border/50 rounded-lg p-6 hover-card overflow-hidden relative group`}
    >
      {/* Gradient background overlay */}
      <div className={`absolute inset-0 bg-gradient-to-br ${colorTheme.bg} to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300`} />
      
      {/* Animated glow effect */}
      <motion.div
        className={`absolute inset-0 rounded-lg opacity-0 group-hover:opacity-20 blur-xl transition-opacity duration-300`}
        style={{
          background: `linear-gradient(135deg, var(--${color.replace('-', '_')}), transparent)`,
        }}
      />

      <div className="flex items-start justify-between relative z-10">
        <div className="flex-1">
          <p className="text-sm font-medium text-muted-foreground mb-2 uppercase tracking-wide">
            {label}
          </p>
          <div className="flex items-baseline gap-2">
            {prefix && <span className="text-foreground text-xs">{prefix}</span>}
            <motion.p
              className={`text-3xl sm:text-4xl font-bold text-transparent bg-clip-text bg-gradient-to-r ${colorTheme.gradient}`}
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ duration: 0.5, delay: 0.1 }}
            >
              {formattedValue}
            </motion.p>
            {suffix && <span className="text-foreground text-sm font-medium">{suffix}</span>}
          </div>
        </div>
        {icon && (
          <motion.div
            className={`${colorTheme.iconColor} opacity-80 group-hover:opacity-100 transition-opacity duration-300`}
            whileHover={{ rotate: 10, scale: 1.1 }}
            transition={{ type: 'spring', stiffness: 400, damping: 10 }}
          >
            {icon}
          </motion.div>
        )}
      </div>
    </motion.div>
  )
}
